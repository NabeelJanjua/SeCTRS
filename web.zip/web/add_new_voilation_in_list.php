<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
</head>
<body>
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
        <!-- Start Content Box -->
   
    <?php
include("db.php");
$dbConnect = new DBConnect();
$res  = $dbConnect->search_all_reg_no();
?>
    <div class="content-box-header"><h3>Add new Voilation in Voilation List </h3></div> 
        <div class="content-box-content">
    <form action="controler.php" method="POST" >
 
    Voilation Name:<br>
    <input type="text" id="voilation_discription" name="voilation_discription" placeholder="Enter Voilation Name"  pattern='[A-Z a-z\\s]*' required/> <br><br>Voilation Fee:<br>
    <input type="number" id="fee" name="fee" placeholder=" Fee" min="100" max="5000" required/>
    <input type="submit" name="add_voilation" value="Click" />
    </form>


  <div style="clear: both;" id="result">
    <?php
if(isset($_GET['message']))
{
  echo $_GET['message'];

}
 ?>   
  </div>




        <!--Your Code goes here this is the rest of thebody wher data will be display -->
     </div>
	 </div>
	  <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
