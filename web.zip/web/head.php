<?php
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>

    <!-- Reset Stylesheet -->
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/invalid.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/blue.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/default.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/debug.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/spread.css" type="text/css" media="screen">
    <script type="text/javascript" src="js/prototype.js"></script>
    <script type="text/javascript" src="js/window.js"></script>
    <script type="text/javascript" src="js/window_ext.js"></script>
    <script type="text/javascript" src="js/effects.js"></script>
    <script type="text/javascript" src="js/debug.js"></script>
    <script type="text/javascript" src="js/extended_debug.js"></script>
    <script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
    <!-- jQuery Configuration -->
   <script type="text/javascript" src="js/simpla.jquery.configuration.js"></script>
    <!-- Facebox jQuery Plugin -->
    <script type="text/javascript" src="js/facebox.js"></script>
    <!-- jQuery WYSIWYG Plugin -->
    <script type="text/javascript" src="js/jquery.wysiwyg.js"></script>
    <style type="text/css">
        #progressBackgroundFilter
        {
            position: fixed;
            top: 0px;
            bottom: 0px;
            left: 0px;
            right: 0px;
            overflow: hidden;
            padding: 0;
            margin: 0;
            background-color: #000;
            filter: alpha(opacity=50);
            opacity: 0.5;
            z-index: 1000;
            height: 100%;
        }
        #processMessage
        {
            position: fixed;
            top: 200px;
            left: 43%;
            padding: 10px;
            width: 14%;
            z-index: 1001;
            background-color: #fff;
            text-align: center;
        }
        .ddlClass
        {
            font-size: 18px;
            height: 30px;
            line-height: 30px;
            width: 100px; /*
scrollbar-face-color: #FFCCCC;
scrollbar-highlight-color: #4B4B4B;
scrollbar-3dlight-color: #646464;
scrollbar-darkshadow-color: #969696;
scrollbar-shadow-color: #C0C0C0;
scrollbar-arrow-color: #090925;
scrollbar-track-color: #051011;*/
        }
        .pgr
        {
            background: #424242 url(grd_pgr.png) repeat-x top;
        }
        .pgr table
        {
            margin: 5px 0;
        }
        .pgr td
        {
            border-width: 0;
            padding: 0 6px;
            border-left: solid 1px #666;
            font-weight: bold;
            color: #fff;
            line-height: 12px;
        }
        .pgr a
        {
            color: #666;
            text-decoration: none;
        }
        .pgr a:hover
        {
            color: #000;
            text-decoration: none;
        }
        
        /*by adil Start*/
        
          .Initial
        {
            display: block;
            padding: 2px 10px 4px 12px;
            float: left;
            background: url("../images/InitialImage.png") no-repeat right top;
            color: Black;
            font-weight: bold;
        }
        .Initial:hover
        {
            color: White;
            background: url("../images/SelectedButton.png") no-repeat right top;
        }
        .Clicked
        {
            float: left;
            display: block;
            background: url("../images/SelectedButton.png") no-repeat right top;
            padding: 2px 10px 4px 12px;
            color: Black;
            font-weight: bold;
            color: White;
        }
        /*by adil End*/
        
    </style>