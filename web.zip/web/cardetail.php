<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
</head>
<body>
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
        <!-- Start Content Box -->
   
    <?php

include("db.php");
$dbConnect = new DBConnect();
if(isset($_GET['regno']))
{
  $reg_no=$_GET['regno'];
$res  = $dbConnect->search_reg_no($reg_no);
?>
    <div class="content-box-header"><h3>Car Information </h3></div> 
      <div class="content-box-content">
    <table class="table">
           <col width="200"/>
           <tr class="GridHeader">
          <th>Type</th>
         <th>Value</th>
         </tr>
    <?php
$res  = $dbConnect->search_reg_no($reg_no);
   while($row  = mysqli_fetch_object($res))
    {
     
    $reg_no=$row->vehicle_registration_number;
    $owner=$row->owner_name;
    $colorr=$row->color;
    $owner_fatherr_name=$row->owner_father_name;
    $engine_number=$row->engine_number;
    $chasis_number=$row->chasis_number;
    $model=$row->model;
    $marker_name=$row->maker_name;

    ?>
    <tr><td>Vehical Reg_No</td><td><?php echo $reg_no; ?></td></tr>
    <tr><td>Owner Name</td><td><?php echo $owner; ?> </td></tr>
    <tr><td>Owner Father Name</td><td><?php echo $owner_fatherr_name; ?> </td></tr>
    <tr><td>Color</td><td><?php echo $colorr; ?> </td></tr>
    <tr><td>Engine Number</td><td><?php echo $engine_number; ?> </td></tr>
    <tr><td>Model</td><td><?php echo $model; ?> </td></tr>
    <tr><td>Marker NAME</td><td><?php echo $marker_name; ?> </td></tr>
    <tr><td>Chasis Number</td><td><?php echo $chasis_number; ?> </td></tr>

    
<?php 
 
}
 }
 echo '</table>
 </br>
<a class="button" href="allcar.php">Back</a>

 ';


?>
        <!--Your Code goes here this is the rest of thebody wher data will be display -->
     </div>
   </div>
    <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
