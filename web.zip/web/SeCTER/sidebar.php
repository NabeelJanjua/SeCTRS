<div id="sidebar-wrapper">
  <!-- Sidebar with logo and menu -->
  <!-- Logo (221px wide) -->
  <center>
    <a href="#"> <img id="ctl00_logo" src="images/CIITLogo_Plain.png" alt="COMSATS" style="border-width:0px;"> </a>
  </center>
  <!-- Sidebar Profile links -->
  <div id="profile-links" style="text-align: center;"> <span id="ctl00_Label1" style="font-size:16pt;">Welcome,</span> <br>
    <br>
    <a id="ctl00_lnk_Notifications" title="Notifications" href="javascript:__doPostBack(&#39;ctl00$lnk_Notifications&#39;,&#39;&#39;)" style="font-size: 10pt">Notifications</a> | <a id="ctl00_lnk_Signout" href="javascript:__doPostBack(&#39;ctl00$lnk_Signout&#39;,&#39;&#39;)" style="font-size: 10pt">Sign 
    Out</a> </div>
  <ul id="main-nav">
    <!-- Accordion Menu -->
    <li> <a id="ctl00_lnk_Dashboard" class="nav-top-item no-submenu" href="javascript:__doPostBack(&#39;ctl00$lnk_Dashboard&#39;,&#39;&#39;)">Dashboard</a> </li>
    <li>
      <ul style="display: none;">
        <li> </li>
        <li> </li>
      </ul>
    </li>
    <li><a id="ctl00_lnk_Courses" class="nav-top-item">
      <!-- Add the class "current" to current menu item -->
      Courses </a>
      <ul style="display: none;">
        <li> <a id="ctl00_lnk_Summary" href="javascript:__doPostBack(&#39;ctl00$lnk_Summary&#39;,&#39;&#39;)">Summary</a></li>
        <li> <a id="ctl00_lnk_ClassProceedings" href="javascript:__doPostBack(&#39;ctl00$lnk_ClassProceedings&#39;,&#39;&#39;)">Class Proceedings</a></li>
        <li> <a id="ctl00_lnk_QAMarks" href="javascript:__doPostBack(&#39;ctl00$lnk_QAMarks&#39;,&#39;&#39;)">Q.A/Sess/Final 
          Marks</a></li>
        <!-- Add class "current" to sub menu items also -->
      </ul>
    </li>
    <li><a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#" id="ctl00_lnkProjectMain" class="nav-top-item"> Projects </a>
      <ul style="display: none;">
        <li><a href="https://sis.cuonlineatd.edu.pk/FinalProject/ProjectComments.aspx" id="ctl00_lnkProjectTasks">Project Tasks</a></li>
      </ul>
    </li>
    <li><a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#" id="ctl00_lnkTimeTableMain" class="nav-top-item"> Time Table </a>
      <ul style="display: none;">
        <li><a href="https://sis.cuonlineatd.edu.pk/TimeTable.aspx" id="ctl00_lnkTimeTable">TimeTable</a></li>
      </ul>
    </li>
    <li><a id="ctl00_lnkLibraryMain" class="nav-top-item">Library</a>
      <ul style="display: none;">
        <li><a href="https://sis.cuonlineatd.edu.pk/BooksReserved.aspx" id="ctl00_lnkReserveBook">Book Reservation</a></li>
        <li><a href="https://sis.cuonlineatd.edu.pk/BookBorrowHistory.aspx" id="ctl00_lnkBookBorrowHistory">Book Borrow
          History</a></li>
      </ul>
    </li>
    <li id="ctl00_lstConvocation" style="Display:none"><a href="#" id="ctl00_lnkConvocationRegistration" class="nav-top-item" style="Display:none">Convocation Registration </a>
      <ul style="display: none;">
        <li> <a id="ctl00_lnkRegister" href="#" style="Display:none">Register</a></li>
      </ul>
    </li>
    <li><a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#" id="ctl00_lnkClearanceMain" class="nav-top-item">University
      Clearance </a>
      <ul style="display: none;">
        <li> <a id="ctl00_lnkApplyForClearance" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$lnkApplyForClearance&quot;, &quot;&quot;, false, &quot;&quot;, &quot;Clearance/AddStudentClearanceDetails.aspx&quot;, false, true))">Apply</a></li>
        <li> <a id="ctl00_lnkClearanceStatus" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$lnkClearanceStatus&quot;, &quot;&quot;, false, &quot;&quot;, &quot;Clearance/ViewClearanceByUser.aspx&quot;, false, true))">View Status</a></li>
      </ul>
    </li>
    <li> <a id="ctl00_lnkGraduateProfile" class="nav-top-item no-submenu" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$lnkGraduateProfile&quot;, &quot;&quot;, false, &quot;&quot;, &quot;#&quot;, false, true))" style="Display:none">Graduate Progress Profile</a> </li>
    <li><a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#" id="ctl00_lnk_Settings" class="nav-top-item">Settings</a>
      <ul style="display: none;">
        <li> <a id="ctl00_lnk_Profile" href="javascript:__doPostBack(&#39;ctl00$lnk_Profile&#39;,&#39;&#39;)">Profile</a> </li>
        <li> <a id="ctl00_lnk_ChangePassword" href="javascript:__doPostBack(&#39;ctl00$lnk_ChangePassword&#39;,&#39;&#39;)">Change 
          Password</a></li>
        <li> <a id="ctl00_lnk_LoginHistory" href="javascript:__doPostBack(&#39;ctl00$lnk_LoginHistory&#39;,&#39;&#39;)">Login 
          History</a></li>
      </ul>
    </li>
  </ul>
  <!-- End #main-nav -->
  <!-- End #messages -->
</div>
