
<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Website Traffic</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="css/main.css" media="screen" />
<script type="text/javascript">
  // toggle dynamic divs
    function toggle(div) {
      var elem = document.getElementById(div);
      if (elem.style.display=='') {elem.style.display='none'; return;}
      elem.style.display='';
    }
  </script>
</head>
<body>
<div id="content" style="height:700px;width:1023px">
  <div id="header">
  
    <div id="search"> <a onclick="toggle('searchform');">+ SEARCH</a>
      <div id="searchform" style="display: none;">
        <form method="post" action="http://all-free-download.com/free-website-templates/">
          <p>
            <input class="searchfield" name="search_query" id="keywords" value="Search Keywords" type="text" />
            <input class="searchbutton" name="submit" value="Search" type="submit" />
          </p>
        </form>
      </div>
    </div>
  </div>
  <ul id="menu">
    <li><a class="current" href="index.php">Home</a></li>
    <li><a href="map.php">Search Voilation</a></li>
    <li><a href="new-voilation.php">New Voilation</a></li>
    <li><a href="viewcar.php">View</a></li>
    <li><a href="http://all-free-download.com/free-website-templates/">Accessibility Test</a></li>
    <li><a href="http://all-free-download.com/free-website-templates/">About</a></li>
    <li><a id="last" href="http://all-free-download.com/free-website-templates/">Contact</a></li>
  </ul>
  <div style="clear: both;" style="height:700px;width:1023px"> yes i am here in div</div>

<div id="footer">
  <p class="right"><a href="">Sitemap</a><a href="http://all-free-download.com/free-website-templates/">Contact</a></p>
  <p>© Copyright 2008, <a href="http://all-free-download.com/free-website-templates/">Website Traffic</a>, Design: <a href="http://www.solucija.com">Luka Cvrk</a></p>
</div>
</html>
