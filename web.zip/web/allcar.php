<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
</head>
<body>
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
        <!-- Start Content Box -->
   
    <?php
include("db.php");
$dbConnect = new DBConnect();
$res  = $dbConnect->search_all_reg_no();
echo'
    <div class="content-box-header"><h3>All Car Registration Number </h3></div> 
    <div class="content-box-content">
    <table class="table">
    <tr class="GridHeader">
    <th>Registration No.</th>
    <th>Owner Name</th>
    <th>View Car Details</th>
    <th>View Voilation Details</th>
</tr>
    ';

   while($row  = mysqli_fetch_object($res))
    {
     
  $reg_no=$row->vehicle_registration_number;
   $owner=$row->owner_name;
    
    ?>
    <tr class="GridColumn"><td><?php echo $reg_no; ?></a> </td>
    <td><?php echo $owner; ?> </td>
    <td><a href="cardetail.php?regno=<?php echo $reg_no;?>">view</a> </td>
    <td><a href="voilationdetail.php?regno=<?php echo $reg_no;?>">view</a> </td>
    </tr>


    
<?php 
 

 }
 echo '</table>';


?>
        <!--Your Code goes here this is the rest of thebody wher data will be display -->
     </div>
	 </div>
	  <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
