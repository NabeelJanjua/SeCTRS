-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2016 at 03:13 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `secter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin123'),
(2, 'faisal@gmail.com', 'faisal123');

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE IF NOT EXISTS `car` (
  `vehicle_registration_number` varchar(100) NOT NULL,
  `maker_name` varchar(100) NOT NULL,
  `chasis_number` int(11) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `color` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `engine_number` varchar(100) NOT NULL,
  `owner_father_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`vehicle_registration_number`, `maker_name`, `chasis_number`, `owner_name`, `color`, `model`, `engine_number`, `owner_father_name`) VALUES
('D 2324', 'SUZUKI VAN', 801618, 'COL MUKHTAR AHMED', 'White', '1992', '566743', 'MUMTAZ AHMED'),
('E 1234', 'mehran', 3455, 'umer', 'red', '5675', '858895', 'khan'),
('E 3333', 'mehran khan', 3455, 'umer hmdan', 'red green', '5675', '858895', 'khan saab'),
('R 1234', 'ZAHID', 1234, 'ADEEL ANJUM', 'RED', '1992', 'A4SHDF', 'MIR AFZAL');

-- --------------------------------------------------------

--
-- Table structure for table `voilation`
--

CREATE TABLE IF NOT EXISTS `voilation` (
  `v_id` int(11) NOT NULL,
  `voilation_type` int(11) NOT NULL,
  `car_number` varchar(50) NOT NULL,
  `lng` float NOT NULL,
  `lat` float NOT NULL,
  `city` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `fee` int(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voilation`
--

INSERT INTO `voilation` (`v_id`, `voilation_type`, `car_number`, `lng`, `lat`, `city`, `date`, `fee`) VALUES
(1, 1, 'E 1234', 73.2346, 34.1616, 'abbotabad', '2016-06-15', 100),
(2, 1, 'E 3333', 73.236, 34.2, 'abbotabad', '2016-06-16', 200),
(3, 1, 'E 5555', 73.9, 34.9, 'bannu', '2016-06-16', 300),
(4, 2, 'U 6655', 73, 34, 'bannu', '2016-06-17', 400),
(5, 1, 'E 1234', 73, 34, 'kohat', '26-4-1014', 100),
(6, 3, 'reg_no', 73.9, 34.6, 'abbottabad', '2016-02-17', 300),
(7, 1, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-02-17', 100),
(8, 2, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-02-17', 200),
(17, 1, 'D 1214', 73.9, 34.6, 'abbottabad', '2016-03-12', 100),
(18, 4, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-13', 0),
(19, 2, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-13', 600),
(20, 2, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-13', 200),
(21, 4, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-13', 400),
(22, 1, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-13', 100),
(23, 3, 'D 1214', 73.9, 34.6, 'abbottabad', '2016-03-13', 300),
(24, 2, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-13', 200),
(25, 1, 'D 2324', 73.9, 34.6, 'abbottabad', '2016-03-16', 100);

-- --------------------------------------------------------

--
-- Table structure for table `voilation_list`
--

CREATE TABLE IF NOT EXISTS `voilation_list` (
  `voilation_id` int(11) NOT NULL,
  `voilation_discription` varchar(100) NOT NULL,
  `challan_fee` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voilation_list`
--

INSERT INTO `voilation_list` (`voilation_id`, `voilation_discription`, `challan_fee`) VALUES
(1, 'Wrong Overtake', 100),
(2, 'Wrong Parking', 200),
(3, 'Wrong Uturn', 300),
(4, 'Illegal Horn', 400),
(5, 'NOT ', 344),
(6, 'wrongturn ', 100),
(7, 'yrt sdfia ', 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`vehicle_registration_number`);

--
-- Indexes for table `voilation`
--
ALTER TABLE `voilation`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `voilation_list`
--
ALTER TABLE `voilation_list`
  ADD PRIMARY KEY (`voilation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `voilation`
--
ALTER TABLE `voilation`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `voilation_list`
--
ALTER TABLE `voilation_list`
  MODIFY `voilation_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
