<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
</head>
<body>
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
        <!-- Start Content Box -->


   
    <?php

include("db.php");
$dbConnect = new DBConnect();
$res  = $dbConnect->get_voilation_type_id();
?>
<h3>Search by City</h3>
<table>
<tr><td>
  <select  id="Voilation_type" onchange="getvoilationtype()"  >
 <option value="None">None</option>
 <?php
 while($row  = mysqli_fetch_object($res))
    {
       $voilation_id=$row->voilation_id;
       $voilation_description=$row->voilation_discription;
      ?>
       <option value=<?php echo $voilation_id ?> > <?php  echo $voilation_description ?> </option>
 <?php    
}
?>
</select>
</form>
</td>

<td><a class="button" href="voilatio_car_no.php?reg=<?php echo $voilation_id;?>">Search</a></td>
</tr>
</table>





<?php

if(isset($_GET['regno']))
{
  $reg_no=$_GET['regno'];
if(!isset($_Post['submit']))
{
  $res  = $dbConnect->search_reg_no_by_voilation($reg_no);
?>
    <div class="content-box-header"><h3>Voilation Detail </h3></div> 
      <div class="content-box-content">
 
    <?php
    $vno=0;
   while($row  = mysqli_fetch_object($res))
    {
     
    $voilation_type=$row->voilation_type;
    $result=$dbConnect->get_voilation_name_by_type($voilation_type);
    $v_row= mysqli_fetch_object($result);
    $voilation_description=$v_row->voilation_discription;

    $car_number=$row->car_number;
    $lng=$row->lng;
    $lat=$row->lat;
    $city=$row->city;
    $date=$row->date;
    $fee=$row->fee;
    

    ?>
    <div class="content-box">

    <div class="content-box-header"><h3>Voilation No. <?php echo ++$vno; ?></h3></div> 
    <div class="content-box-content">
    <table class="table">
    <col width="200"/>
    <tr class="GridHeader">
    <th>Type</th>
    <th>Value</th>
    </tr>
    <tr><td>Car Reg_No</td><td><?php echo $car_number; ?></td></tr>
    <tr><td>Voilation Type</td><td><?php echo $voilation_description; ?> </td></tr>
    <tr><td>Langitude</td><td><?php echo $lng; ?> </td></tr>
    <tr><td>Latitude</td><td><?php echo $lat; ?> </td></tr>
    <tr><td>City</td><td><?php echo $city; ?> </td></tr>
    <tr><td>Date</td><td><?php echo $date; ?> </td></tr>
    <tr><td>Fee</td><td><?php echo $fee; ?> </td></tr>
</table>

</div>
</div> 

<?php }
 
}
 }
 echo '</table>;
 </br>
<a class="button" href="allcar.php">Back</a>'


?>
        <!--Your Code goes here this is the rest of thebody wher data will be display -->
     </div>
   </div>
    <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
