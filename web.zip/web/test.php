<?php


class DBConnect
{
	private $dbName = "secter";
	private $hostname = "localhost";
	private $username = "root";
	private $password = "";
	private $db;
       function __construct()
	{   
		$error = "Error Connecting to Database";
		$this->db = mysqli_connect($this->hostname,$this->username,$this->password,$this->dbName) 
				or die ($error);
	}

	
		function Voilation_show_on_map($type)
	{

		$query = "SELECT * FROM voilation WHERE voilation_type = '$type'";
    $result = $this->db->query($query) or die("Error ".mysqli_error($db));
    

    if(mysqli_num_rows($result)>0) {
return $result;
    }
      else
      return null;
 
	}

	function voilation_show_by_date()
	{
		$query="SELECT * FROM voilation where date(starttime) >= date '2015-01-01';";
		$result=$this->db->query($query) or die("Error ".mysqli_error($db));
		 if(mysqli_num_rows($result)>0) {
       return $result;
    }
      else
      return null;
	}


	function get_fee($type)
	{
		$query="SELECT * FROM voilation_list WHERE voilation_id='$type'";
		$result=$this->db->query($query) or die("Error".mysqli_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;

	}

	function select($s,$e)
		{

				//$query = "INSERT INTO mytable (username, password) VALUES ('ehsan1', '123123')";
		//$deleteQuery = "DELETE FROM mytable WHERE username = 'ehsan'";
		//$updateQuery = "UPDATE mytable SET username = 'ehsanwaris' WHERE id = 2";
		//$selectQuery = "SELECT * FROM mytable";
		
		//$query="SELECT * FROM voilation";
			$query="SELECT * FROM voilation where date >=  '$s' AND date <= '$e';";
		$res=$this->db->query($query) or die("Error".mysqli_error($db));
		
		//var_dump($res);
		echo "<table border=1>";
		echo "<tr>";
			echo "<th>ID</th>";
			echo "<th>Username</th>";
			echo "<th>Password</th>";
				echo "</tr>";
		while ($row =$res->fetch_object())
		{
			echo "<tr>";
			echo "<td>".$row->lng."</td>";
			echo "<td>".$row->car_number."</td>";
			echo "<td>".$row->date."</td>";
				echo "</tr>";
		}
		echo "</table>";
		
			echo "<br> After Loop";
		/*$row =$res->fetch_object();
		
			
			echo $row->id;
			echo $row->username;
			echo $row->password;*/
		
		
	}

	
}

$dbConnect = new DBConnect();
$dbConnect->select('2016-06-16','2018-06-16');


?>