<?php

if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>

<?php


class DBConnect
{
	private $dbName = "secter";
	private $hostname = "localhost";
	private $username = "root";
	private $password = "";
	private $db;
       function __construct()
	{   
		$error = "Error Connecting to Database";
		$this->db = mysqli_connect($this->hostname,$this->username,$this->password,$this->dbName) 
				or die ($error);
	}

	function login($email, $password)
	{
		$query = "SELECT * FROM admin WHERE email ='$email' AND password = '$password'";
		$result = $this->db->query($query) or die("Error ".mysqli_error($this->db));
		if(mysqli_num_rows($result)>0)
			return true;
			else
			return false;
	}

	
		function Voilation_show_on_map($type)
	{


		$query = "SELECT * FROM voilation WHERE voilation_type = '$type'";
    $result = $this->db->query($query) or die("Error ".mysqli_error($db));
    

    if(mysqli_num_rows($result)>0) {
return $result;
    }
      else
      return null;
 
	}

	function voilation_show_by_date($sdate,$edate)
	{
		
		$query="SELECT * FROM voilation where date >=  '$sdate' AND date <= '$edate'";
		$result=$this->db->query($query) or die("Error ".mysqli_error($db));

		 if(mysqli_num_rows($result)>0) {
       return $result;
    }
      else
      return null;
	}

		function Voilation_show_by_city($city)
	{


		$query = "SELECT * FROM voilation WHERE city = '$city'";
    $result = $this->db->query($query) or die("Error ".mysqli_error($db));
    

    if(mysqli_num_rows($result)>0) {
return $result;
    }
      else
      return null;
 
	}


	function get_fee($type)
	{
		$query="SELECT * FROM voilation_list WHERE voilation_id='$type'";
		$result=$this->db->query($query) or die("Error".mysqli_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;

	}


	function search_reg_no($reg_no)
	{
		$query="SELECT * FROM car WHERE vehicle_registration_number='$reg_no' ";
		$result=$this->db->query($query) or die("Error".mysql_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;
	}



function insert_this($color, $reg_no, $owner_name, $owner_father_name, $engine_number, $chasis_number,$model,$marker_name)
{
$query="INSERT INTO `car` (`vehicle_registration_number`, `maker_name`, `chasis_number`, `owner_name`, `color`, `model`, `engine number`, `owner_father_name`) VALUES ('$reg_no', '$marker_name', '$chasis_number', '$owner_name', '$color', '$model', '$engine_number', '$owner_father_name');";
	if($this->db->query($query)) 
		
		return 1;

		else 
		die("Error".mysql_error($db));

}

function insert_voilation($voilation_type,$reg_no,$lng,$lat,$city,$date,$fee)
{
	$query="INSERT INTO `voilation` (`v_id`, `voilation_type`, `car_number`, `lng`, `lat`, `city`, `date`, `fee`) VALUES ( NULL,'$voilation_type', '$reg_no', '$lng', '$lat', '$city', '$date', '$fee');";
	if($this->db->query($query)) 		
		return 1;
	else 
	    die("Error".mysql_error($db));
}

function insert_voilation_in_voilation_list($v_d,$fee)
{
	$query="INSERT INTO `voilation_list` (`voilation_id`, `voilation_discription`, `challan_fee`) VALUES (NULL, '$v_d ', '$fee');";
	if($this->db->query($query)) 		
		return 1;
	else 
	    die("Error".mysql_error($db));
}
/////////////////////////////////////////// View all the function.///////////////////////////////////////////.........


function search_all_reg_no()
{
	$query="SELECT * FROM car";
	$result=$this->db->query($query) or die("Error".mysqli_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;
}

	function search_reg_no_by_voilation($reg_no)
	{
		$query="SELECT * FROM voilation WHERE car_number='$reg_no' ";
		$result=$this->db->query($query) or die("Error".mysql_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;
	}

	function get_voilation_name_by_type($voilation_type)
	{
		$query="SELECT voilation_discription FROM `voilation_list` WHERE voilation_id= '$voilation_type'";
		 $result=$this->db->query($query) or die("Error".mysql_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;
	}

	function get_voilation_type_id()
	{
		$query="SELECT * FROM `voilation_list`";
		 $result=$this->db->query($query) or die("Error".mysql_error($db));
		if(mysqli_num_rows($result)>0){

			return $result;
		}
		else
			return null;
	}


	function select($type)
	{
				//$query = "INSERT INTO mytable (username, password) VALUES ('ehsan1', '123123')";
		//$deleteQuery = "DELETE FROM mytable WHERE username = 'ehsan'";
		//$updateQuery = "UPDATE mytable SET username = 'ehsanwaris' WHERE id = 2";
		//$selectQuery = "SELECT * FROM mytable";
		
		$q="SELECT * FROM voilation_list WHERE voilation_id='$type'";
		
		$res =  $this->db ->query($q) or die("Error ".mysqli_error($db));
		
		//var_dump($res);
		echo "<table border=1>";
		echo "<tr>";
			echo "<th>ID</th>";
			echo "<th>Username</th>";
			echo "<th>Password</th>";
				echo "</tr>";
		while ($row =$res->fetch_object())
		{
			echo "<tr>";
			echo "<td>".$row->voilation_id."</td>";
			echo "<td>".$row->challan_fee."</td>";
			//echo "<td>".$row->password."</td>";
				echo "</tr>";
		}
		echo "</table>";
		
			echo "<br> After Loop";
		/*$row =$res->fetch_object();
		
			
			echo $row->id;
			echo $row->username;
			echo $row->password;*/
		
		
	}

	
}


?>