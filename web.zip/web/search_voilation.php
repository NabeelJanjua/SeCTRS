<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcZeHTv7ulSMvkJWSaF5H5Q_HSKQv-_qo"
  type="text/javascript"></script>
<script type="text/javascript">
    
  // toggle dynamic divs
   function toggle(div) {
    	var elem = document.getElementById(div);
    	if (elem.style.display=='') {elem.style.display='none'; return;}
    	elem.style.display='';
    } 



//
function getViolations() {
  var date1 = document.getElementById("sdate");
        var date2 = document.getElementById("edate");
        var startdate = date1.value;
        var enddate=date2.value;
        if(startdate<enddate && startdate!='' && enddate!='')
        {
     

       var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
               // alert('done');
                 console.log(xmlhttp.responseText);
               putMarker(xmlhttp.responseText);
            }
        };
         xmlhttp.open("GET","ajax.php?startdate=" + startdate + "&enddate=" + enddate , true);
        xmlhttp.send();
      }
      else
      {
              alert('yes less')
          var errorMsg = "<p>Invalid date </p>"
document.getElementById("err").innerHTML = errorMsg;
putMarker(xmlhttp.responseText);
        }
}

function getcity()
{
  var city = document.getElementById("city_name").value;
  alert(city);
  var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
               // alert('done');
                 console.log(xmlhttp.responseText);
               putMarker(xmlhttp.responseText);
            }
        };
             xmlhttp.open("GET","ajax.php?city=" + city , true);
             xmlhttp.send();
}
function getvoilationtype() {
  
//alert(enddate);
  var e = document.getElementById("Voilation_type");
  type = e.options[e.selectedIndex].value;
    
alert();
       var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
               // alert('done');
                 console.log(xmlhttp.responseText);
               putMarker(xmlhttp.responseText);
            }
        };
             xmlhttp.open("GET","ajax.php?type=" + type , true);
             xmlhttp.send();
}

function putMarker(data) {
  var mapProp = {
    center: new google.maps.LatLng(34.2000592, 73.2403229),
    zoom:9,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

    markers = JSON.parse(data);//The JavaScript function JSON.parse(text) can be used to convert a JSON text into a JavaScript object
    for (var i = 0; i < markers.length; i++) {
      // console.log(markers[i]['lat']);
      var location = new google.maps.LatLng(markers[i]['lat'], markers[i]['lng']);
        var marker = new google.maps.Marker({
            position: location,
            map: map
        });
    };
  }







  function loadScript()
{
  // var script = document.createElement("script");
  // script.type = "text/javascript";
  // script.src = "http://maps.googleapis.com/maps/api/js?key=&sensor=false&callback=initialize";
  // document.body.appendChild(script);
}

window.onload = loadScript;
  </script>
</head>
<body onunload="GUnload()">
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box" align="center">
        <!-- Start Content Box -->
    <div class="content-box-header"><h3>Select Your choice</h3></div> 
    <div class="content-box-content">
    <table class="table">
    <tr>
   <td> <form>
    <h2 style="color:black;">Select Voilation Type</h2>
     <?php
      include("db.php");
      $dbConnect = new DBConnect();
      $res  = $dbConnect->get_voilation_type_id();
      ?></td><td>
  <select  id="Voilation_type" onchange="getvoilationtype()"  >
      <option value="None">None</option>
      <?php
      while($row  = mysqli_fetch_object($res))
        {
          $voilation_id=$row->voilation_id;
          $voilation_description=$row->voilation_discription;
          ?>
       <option value=<?php echo $voilation_id ?> > <?php  echo $voilation_description ?> </option>
          <?php    
        }
        ?>
  </select>
</form></td>
</tr>
<tr>
<form>
<td>
    <h2 style="color:black;">Search by date wise</h2></td>
    <td>
    From:
    <!-- mm/dd/yyyy -->
      <input type="date" name="sdate" id="sdate" max="2030-01-02" value="2014-01-01" >    
     TO
      <input type="date" name="edate" id="edate" min="2014-01-01" value="2017-12-06"><br><br>
       <select style="margin-left: 10px;"  id="Voilation_type" onmouseover="getViolations()" onchange="getViolations()">
      <option>Search</option>
     </select>
      </td>
</form>
</tr>
<tr>
<form>
<td>

<h2 style="color: black">Search by City</h2></td><td>
 <select id="city_name" name="city_name" class="" onchange="getcity()" >
                          <option selected="selected" value="">-- Select District --</option>
                          <option value=abbotabad>Abbottabad</option>
                          <option value=bannu>Bannu</option>
                          <option value=battagram>Battagram</option>
                          <option value=buner>Buner</option>
                          <option value=charsadda>Charsadda</option>
                          <option value=chitral>Chitral</option>
                          <option value=dikhan>Dera Ismail Khan</option>
                          <option value=hangu>Hangu</option>
                          <option value=haripur>Haripur</option>
                          <option value=karak>Karak</option>
                          <option value=kohat>Kohat</option>
                          <option value=kohistan>Kohistan</option>
                          <option value=lmarwat>Lakki Marwat</option>
                          <option value=lower_dir>Lower Dir (PATA)</option>
                          <option value=malakand>Malakand (PATA)</option>
                          <option value=mansehra>Mansehra</option>
                          <option value=mardan>Mardan</option>
                          <option value=nowshera>Nowshera</option>
                          <option value=peshawar>Peshawar</option>
                          <option value=shangla>Shangla</option>
                          <option value=swabi>Swabi</option>
                          <option value=swat>Swat </option>
                          <option value=tank>Tank</option>
                          <option value=torghar>Tor Ghar</option>
                          <option value=uper_dir>Upper Dir</option>
                        </select>

</td>
</form></tr></table>
 <div id="googleMap" style="width:1000px;height:1000px; border-style: double;
    border-width: thick; " ></div>
<div id="map_canvas" style="width: 100%; height: 100%"></div> 

        <!--Your Code goes here this is the rest of thebody wher data will be display -->
     </div>
	 </div>
	  <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
