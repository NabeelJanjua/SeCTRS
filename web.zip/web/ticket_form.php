<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>


<?php
 $color=$_GET['color'];
 $reg_no=$_GET['car_no'];
$marker_name=$_GET['marker_name'];
$owner_name=$_GET['owner_name'];
$owner_father_name=$_GET['owner_father_name'];
$engine_number=$_GET['engine_number'];
$chasis_number=$_GET['chasis_number'];
$model=$_GET['model'];
$dname=$_GET['dname'];
$dtype=$_GET['dtype'];

?>
<!DOCTYPE html>
<html>
<script type="text/javascript">
function get_date()
{
     var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!

    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var today = yyyy+'-'+mm+'-'+dd;
    document.getElementById("current_date").value = today;
}

function getViolations() {

   var e = document.getElementById("Voilation_type");
    type = e.options[e.selectedIndex].value;
    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                //alert('done');
                 document.getElementById("fee").value =(xmlhttp.responseText);
               (xmlhttp.responseText);
            }
        };
        xmlhttp.open("GET","ajax.php?fee_id=" + type , true);
        xmlhttp.send();
}


</script>


<body onload="get_date()">

<form action="controler.php" method="POST" >
  <fieldset>
    <legend>Voilation Ticket:</legend>
    <table>
    <tr><td>
    Car Number:<br>
    <input type="text" name="reg_no" value="<?php echo $reg_no;?>" required/>
    <br>
     Marker Name:<br>
    <input type="text" name="marker_name" value="<?php echo $marker_name;?>" required/>
    <br>
    Model:<br>
    <input type="text" name="model" value="<?php echo $model;?>" required/>
    <br>
    Owner Name:<br>
    <input type="text" name="owner_name" value="<?php echo $owner_name;?>" required/>
    <br>
    Owner Father Name:<br>
    <input type="text" name="owner_father_name" value="<?php echo $owner_father_name;?>" required/>
    <br>
    Chasis Number:<br>
    <input type="text" name="chasis_number" value="<?php echo $chasis_number;?>" required/>
    <br>
    Engine Number:<br>
    <input type="text" name="engine_number" value="<?php echo $engine_number;?>" required/>
    <br>
    Colour:<br>
    <input type="text" name="color" value="<?php echo $color;?>" required/>
    <br>
    </td>


    <td style="position:absolute;top:36px">
Voilation:<br>
<select  id="Voilation_type" name="voilation_type"  onchange="getViolations()">
 <option value="None">None</option>
<option value="1">Wrong Overtake</option>
<option value="2">Wrong Parking</option>
<option value="3">Wrong Uturn</option>
<option value="4">Illegal Horn</option>
</select>
<br>
 Voilation Fee:<br>
 <input type="text" id="fee" name="fee" placeholder="Challan Fee" required/>
 <br>
 Date:<br>
 <input type="text" id="current_date" name="current_date" required/>
 <br>
 Latitude:<br>
 <input type="text" id="lat" name="lat" value="34.6" required/>
 <br>
 Langitude:<br>
 <input type="text" id="lan" name="lan" value="73.9" required/>
 <br>
  <br>
 City:<br>
 <input type="text" id="city" name="city" value="abbottabad" required/>
 <br>
                     
      

    </td>

    </tr>

    </table>
    
    

    <input type="submit" name="form" value="Submit">
  </fieldset>
</form>

</body>
</html>