<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>

<?php




include("db.php");
$dbConnect = new DBConnect();

 if(isset($_GET['startdate']))
	{

      $sdate=$_GET['startdate'];
      $edate=$_GET['enddate'];
      $res  = $dbConnect->Voilation_show_by_date($sdate,$edate);

$i=0;
   while($row  = mysqli_fetch_object($res))
    {
     
  $Lat=$row->lat; 
   $Lng =$row->lng;
   
   $x[$i]['lat']=$Lat;
   $x[$i]['lng']=$Lng;
 
    $i++;
    
    }  
    echo json_encode($x);
}



else

if(isset($_GET['type']))
{
  $type = $_GET['type'];
  $res  = $dbConnect->Voilation_show_on_map($type);

$i=0;
   while($row  = mysqli_fetch_object($res))
    {
     
  $Lat=$row->lat; 
   $Lng =$row->lng;
   
   $x[$i]['lat']=$Lat;
   $x[$i]['lng']=$Lng;
 
    $i++;
    
   }
echo json_encode($x);
 } 
 else

  if(isset($_GET['city']))
  {
    $city=$_GET['city'];
    $res  = $dbConnect->Voilation_show_by_city($city);
    $i=0;
   while($row  = mysqli_fetch_object($res))
    {
     
  $Lat=$row->lat; 
   $Lng =$row->lng;
   
   $x[$i]['lat']=$Lat;
   $x[$i]['lng']=$Lng;
 
    $i++;
    
   }
echo json_encode($x);

  }

  else

  if(isset($_GET['fee_id']))
  {
  $fee_id = $_GET['fee_id'];

   $res  = $dbConnect->get_fee($fee_id);

   $i=0;
   while($row  = mysqli_fetch_object($res))
    {
     
  $fee=$row->challan_fee;
  echo $fee; 
  }
}


else
  die('Illegal Access');


?>
