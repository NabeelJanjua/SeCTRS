<?php


session_start();
$_SESSION['usermail']= "";
$_SESSION['uname']= "";

?>



<!DOCTYPE html>
<html>
<head>
	
</head>
<body>

<div  align="center" class="textcolor" >
<?php 
  if (isset($_GET['message'])) {
    echo $_GET['message'];
  }
?>
  <h2>Login</h2>
  <form role="form" action="controler.php" method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email"  id="email" name="email" placeholder="Enter email" >
    </div><br><br>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password"  id="pwd" name="pwd" placeholder="Enter password">
    </div><br><br>
    <div class="checkbox">
      <label><input type="checkbox"> Remember me</label>
    </div><br>
   <input type="submit" name="login" value="Login">
  </form>
</div>





</body>
</html>

<?php


if(isset($_GET['error']))
{
  echo $_GET['error'];

}


?>