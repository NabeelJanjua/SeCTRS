``````````````````````````````````````<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
</head>
<body>
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
        <!-- Start Content Box -->
   
    <?php
include("db.php");
$dbConnect = new DBConnect();
$res  = $dbConnect->get_voilation_type_id();
?>
  <select  id="Voilation_type" onchange="getvoilationtype()"  >
 <option value="None">None</option>
 <?php
 while($row  = mysqli_fetch_object($res))
    {
       $voilation_id=$row->voilation_id;
       $voilation_description=$row->voilation_discription;
      ?>
       <option value=<?php echo $voilation_id ?> > <?php  echo $voilation_description ?> </option>
 <?php    
}
?>
</select>





	  <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
