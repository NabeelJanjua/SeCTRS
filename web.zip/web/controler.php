<?php
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>

<?php
include("db.php");
$dbConnect = new DBConnect();
if(isset($_POST['form']))
{
  $color=$_POST['color'];
  $reg_no=$_POST['reg_no'];
  $marker_name=$_POST['marker_name'];
  $owner_name=$_POST['owner_name'];
  $owner_father_name=$_POST['owner_father_name'];
  $engine_number=$_POST['engine_number'];
  $chasis_number=$_POST['chasis_number'];
  $model=$_POST['model'];
  $date=$_POST['current_date'];
  $city=$_POST['city'];
  $lat=$_POST['lat'];
  $lng=$_POST['lan'];
  $fee=$_POST['fee'];
  $voilation_type=$_POST['voilation_type'];
  //echo "<script type='text/javascript'>alert('$reg_no');</script>";exit(1);
  $res  = $dbConnect->search_reg_no($reg_no);
  if($res==NULL)
  {
    //echo "yes i am not //////";
    $dbConnect->insert_voilation($voilation_type,$reg_no,$lng,$lat,$city,$date,$fee);
    $result=$dbConnect->insert_this($color, $reg_no, $owner_name, $owner_father_name, $engine_number, $chasis_number,$model,$marker_name);
    if($result==1)
    {
    $error="Car detail and voilation add successfully.";
    header('Location:new-voilation.php?message=Car detail and voilation add successfully');
    } 
  //echo "<script type='text/javascript'>alert('$lan');</script>";
  }
  else
  {
    $result=$dbConnect->insert_voilation($voilation_type,$reg_no,$lng,$lat,$city,$date,$fee);
    if($result==1)
    {
      $error="Car voilation add successfully.";
      header('Location:new_voliation.php?message=Car voilation add successfully');
    } 

  }
}
else if(isset($_POST['add_voilation']))
{
  $v_d=$_POST['voilation_discription'];
  $fee=$_POST['fee'];
  $result=$dbConnect->insert_voilation_in_voilation_list($v_d,$fee);
  if($result==1)
  {
    $error="Voilation Add in List Successfully";
    header('Location:add_new_voilation_in_list.php?message=Voilation Add in List Successfully');
  } 
  else
  header('Location:add_new_voilation_in_list.php?message=Voilation not Added in List Successfully');
}
else

if(isset($_POST['login']))
{
  session_start();
  $_SESSION['usermail']= "";
  $_SESSION['uname']= "";
  $username = $_POST['email'];
  $password =  $_POST['pwd'];

  $res  = $dbConnect->login($username, $password);

  if($res)
    {
      $_SESSION['usermail']= $username;
        $_SESSION['uname']= "admin";  
      header('Location: home.php');
    }
  else
    {
      $error="User name or password invalid.";
       header('Location: login.php?error=Useremail or password invalid');  
    }

}
else
 echo "this is running";
//$res  = $dbConnect->Voilatio_show_on_map();
	
// if($res == NULL)
//                 {
//                   echo "No voilation avilable.";
//                 }
//                 else
//                 {
//                 	$i=0;
//                    while($row  = mysqli_fetch_object($res))
//                     {
                     
//                   $Lat=$row->Lat; 
//                    $Lng =$row->Lng;
                   
//                    $x[$i]['lat']=$Lat;
//                    $x[$i]['lon']=$Lng;
                 
//                     $i++;
//                }
//                  print_r($x);


//                foreach ($x as $k) {

              
//                	echo "here".$k['lat'];
//                	echo "not".$k['lon'];
//                }
// }
?>