<?php

if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>

<div id="sidebar-wrapper">
  <!-- Sidebar with logo and menu -->
  <!-- Logo (221px wide) -->
  <center>
    <a href="#"> <img id="ctl00_logo" src="images/CIITLogo_Plain.png" alt="COMSATS" style="border-width:0px;"> </a>
  </center>
  <!-- Sidebar Profile links -->
  <div id="profile-links" style="text-align: center;"> <span id="ctl00_Label1" style="font-size:16pt;">Welcome,</span> <br>
    <br>
    <a id="ctl00_lnk_Notifications" title="Notifications" href="">Notifications</a> | <a id="ctl00_lnk_Signout" href="login.php" style="font-size: 10pt">Sign 
    Out</a> </div>
  <ul id="main-nav">
    <!-- Accordion Menu -->
    <li> <a id="ctl00_lnk_Dashboard" class="nav-top-item no-submenu" href="home.php">Home</a> </li>
    <li>
      <ul style="display: none;">
        <li> </li>
        <li> </li>
      </ul>
    </li>
    <li><a id="ctl00_lnk_Courses" class="nav-top-item">
      <!-- Add the class "current" to current menu item -->
      Cars info </a>
      <ul style="display: none;">
        <li> <a id="ctl00_lnk_Summary" href="allcar.php">All Car</a></li>
        

      </ul>
    </li>
    <li><a href="" id="ctl00_lnkProjectMain" class="nav-top-item"> Voilation </a>
      <ul style="display: none;">
        <li><a href="new_voliation.php" id="ctl00_lnkProjectTasks">Add Car Voilation</a></li>
          <li><a href="search_voilation.php" id="ctl00_lnkProjectTasks">Search Voilation</a></li>
      </ul>
    </li>
    <li><a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#" id="ctl00_lnkTimeTableMain" class="nav-top-item"> New </a>
      <ul style="display: none;">
        <li><a href="add_new_voilation_in_list.php" id="ctl00_lnkTimeTable">Add New Voilation</a></li>
      </ul>
    </li>
    
    
    <li> <a id="ctl00_lnkGraduateProfile" class="nav-top-item no-submenu" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$lnkGraduateProfile&quot;, &quot;&quot;, false, &quot;&quot;, &quot;#&quot;, false, true))" style="Display:none">Graduate Progress Profile</a> </li>
    <li><a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#" id="ctl00_lnk_Settings" class="nav-top-item">Settings</a>
      <ul style="display: none;">
        <li> <a id="ctl00_lnk_Profile" href="javascript:__doPostBack(&#39;ctl00$lnk_Profile&#39;,&#39;&#39;)">Profile</a> </li>
      </ul>
    </li>
  </ul>
  <!-- End #main-nav -->
  <!-- End #messages -->
</div>
