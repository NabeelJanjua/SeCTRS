<?php require_once('includes/simple_html_dom.php'); ?>

<?php

$reg = str_replace(' ', '%20', $_GET['reg_no']);
$url = "http://www.kpexcise.gov.pk/mvrecords/getmvr.php?dname=" . $_GET['dname'] . "&dtype=" . $_GET['dtype'] . "&reg_no=$reg";

$html = file_get_html($url);

$records = array();
$count = 0;
$n = 0;
$attName;

foreach($html->find('table') as $record) {
	
	foreach ($record->find('div') as $div) {

		$count++;
		if($count <= 2) {
			continue;
		}

		if (empty($div->plaintext)) {
			$count--;
			continue;
		}

		if ($count%2 != 0) {
			$attName = str_replace(' :', '', $div->plaintext);
			// echo "<b>" . $div->plaintext . "<b> = ";
		} else {
			$records[$n][$attName] = $div->plaintext;
			// echo $div->plaintext;
			// echo "<br>";
		}
	}
	$count = 0;
	$n++;
}
if(empty($records))
{
	$rdata=1;
 echo json_encode($rdata);
}
else{
	echo json_encode($records);
}


?>