<?php
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
 <?php ?>
          <div id="footer">
                    <small>Copyright � 2009 SeCERT <span lang="en-us">
                        <span id="ctl00_LblCampusName" style="font-size:Small;">Abottabad</span></span>|
                        
                        <a href="https://sis.cuonlineatd.edu.pk/FeeHistory.aspx#">Top</a></small>
                </div>