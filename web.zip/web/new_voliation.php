<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<!DOCTYPE html PUBLIC "-//W  3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
<script type="text/javascript">
// toggle dynamic divs
// function toggle(div) {
//   var elem = document.getElementById(div);
//   if (elem.style.display=='') {elem.style.display='none'; return;}
//   elem.style.display='';
// }
function upperMe(){
  var x = document.getElementById("reg_no");
  var reg_no = document.getElementById("reg_no").value;
  var dname= document.getElementById("dname").value;
  if(dname=="none" || reg_no==" ")
  {
   document.getElementById("car_data").innerHTML="<h3>Please Select District or Enter Car Registration Number</h3>";
  }
  else
    cardata();

  x.value = x.value.toUpperCase();
}
function cardata(){
  var reg_no = document.getElementById("reg_no").value;
  var dname= document.getElementById("dname").value;
  var dtype = document.getElementById("dtype").value;
  alert(reg_no);
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
  if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
  {
     if(xmlhttp.responseText==1)  
      {
      document.getElementById("car_data").innerHTML = "<h3>No car data found  inside KPK province, Search again</h3>";
      }
      else
      {
      show_carinformation(xmlhttp.responseText,dname,dtype);
      }
  }
  };
  xmlhttp.open("GET","carinformation.php? reg_no="+reg_no+"&dname="+dname+"&dtype="+dtype, true);
  xmlhttp.send();
}
function show_carinformation(data,dname,dtype){
  var obj=JSON.parse(data);
  console.dir(obj);
  var model=obj[0]['Model'];
   var reg_no=obj[0]['Vehicle Registration Number'];
  var marker_name=obj[0]['Maker Name'];
  var chasis_number=obj[0]['Chasis Number'];
  var engine_number=obj[0]['Engine Number'];
  var owner_name=obj[0]['Owner Name'];
  var color=obj[0]['Color'];
  var owner_father_name=obj[0]['Owner Father Name'];
  var myTable= "<table class='table'>";
  myTable+= "<tr><th class='GridHeader'>Car Number:</th><td class='GridColumn'>"+reg_no+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>Marker Name:</th><td class='GridColumn'>"+marker_name+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>Owner Name:</th><td class='GridColumn'>"+owner_name+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>owner Father Name:</th><td class='GridColumn'>"+owner_father_name+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>Engine Number:</th><td class='GridColumn'>"+engine_number+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>Chasis Number:</th><td class='GridColumn'>"+chasis_number+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>Model:</th><td class='GridColumn'>"+model+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'>Color:</th><td class='GridColumn'>"+color+"</td></tr>";
  myTable+= "<tr><th class='GridHeader'><a href='voilation_ticket.php?color="+color+"&car_no="+reg_no+"&marker_name="+marker_name+"&owner_name="+owner_name+"&owner_father_name="+owner_father_name+"&engine_number="+engine_number+"&chasis_number="+chasis_number+"&model="+model+"&dname="+dname+"&dtype="+dtype+"'>click</a></td></tr>";
  document.getElementById("car_data").innerHTML = myTable;
}

</script>
<style type="text/css">
.drop
{
padding: 4px; 
border-radius: 6px;
background: #fff;
}  
.text1{
    padding: 5px;
    border: 1px solid #d4d4d4;
    border-bottom-right-radius: 5px;
    border-top-right-radius: 4px;
    line-height: 1.5em;
    box-shadow: inset 0px 2px 2px #ececec;
}
</style>
</head>
<body>
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
        <!-- Start Content Box -->
   
    <?php
include("db.php");
$dbConnect = new DBConnect();
$res  = $dbConnect->search_all_reg_no();?>
    <div class="content-box-header"><h3>All Car Registration Number </h3></div> 

    <div class="content-box-content">
<table> 
    <form id="form1" name="form1" method="post" action="" >
      <tr>
        <td>
           <h4>City</h4> </td>
           <td><select id="dname" name="dname" class="drop">
              <option selected="selected" value="none">-- Select District --</option>
              <option value=abbotabad>Abbottabad</option>
              <option value=bannu>Bannu</option>
              <option value=battagram>Battagram</option>
              <option value=buner>Buner</option>
              <option value=charsadda>Charsadda</option>
              <option value=chitral>Chitral</option>
              <option value=dikhan>Dera Ismail Khan</option>
              <option value=hangu>Hangu</option>
              <option value=haripur>Haripur</option>
              <option value=karak>Karak</option>
              <option value=kohat>Kohat</option>
              <option value=kohistan>Kohistan</option>
              <option value=lmarwat>Lakki Marwat</option>
              <option value=lower_dir>Lower Dir (PATA)</option>
              <option value=malakand>Malakand (PATA)</option>
              <option value=mansehra>Mansehra</option>
              <option value=mardan>Mardan</option>
              <option value=nowshera>Nowshera</option>
              <option value=peshawar>Peshawar</option>
              <option value=shangla>Shangla</option>
              <option value=swabi>Swabi</option>
              <option value=swat>Swat </option>
              <option value=tank>Tank</option>
              <option value=torghar>Tor Ghar</option>
              <option value=uper_dir>Upper Dir</option>
            </select>
       
        </td>
        <td width="12%">
        <h4>Registration type</h4></td><td>
            <select id="dtype" name="dtype" class="drop" >
              <option selected="selected" value="reg">Registered</option>
              <option value="temp">Temporary</option>
            </select>
         
        </td>
        <td colspan="2" >
          <div align="right"><h4>Registration No.</h4></div>
        </td>
        <td width="15%">
          <div align="center">
            <input type="text" class="text1" placeholder="i.e: X 1234" name="reg_no" id="reg_no"  maxlength="12"  required="Please Enter Car Registration number" \> 
          </div>
        </td>
        <td> 
          <div> 
            <input name="Search" class="groovybutton" type="button" value="Search" onclick="upperMe()" >
            </div>
        </td>
      </tr>
    </form>
</table>
<!--Your Code goes here this is the rest of thebody wher data will be display -->
</div>
</div>
<div class="content-box">
<div class="content-box-header"><h3>Car Information</h3></div>
<div class="content-box-content">
   <div style="clear: both;" id="car_data">
    <?php
    if(isset($_GET['message']))
    {
      echo'<h4>';
      echo $_GET['message'];
      echo'</h4>';
    }
    else
      echo '<h3> No Car Selected</h3>';
    ?>
    </div>
  </div>
  </div>
	  <?php include('footer.php'); ?>
</div>
</div>
</body>
</html>
