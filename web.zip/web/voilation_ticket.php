<?php
session_start();
if($_SESSION['uname']!="admin")
{
header("location: login.php");
}
?>
<?php
 $color=$_GET['color'];
 $reg_no=$_GET['car_no'];
$marker_name=$_GET['marker_name'];
$owner_name=$_GET['owner_name'];
$owner_father_name=$_GET['owner_father_name'];
$engine_number=$_GET['engine_number'];
$chasis_number=$_GET['chasis_number'];
$model=$_GET['model'];
$dname=$_GET['dname'];
$dtype=$_GET['dtype'];

?>
``````````````````````````````````````<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0046)https://sis.cuonlineatd.edu.pk/FeeHistory.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Showing Alert Message On Page load For feed Back-->
<title>SeCTER</title>
<!--                       CSS                       -->
 <?php include('head.php'); ?>
 <style type="text/css">
input[type=text] {
    padding: 5px;
    border: 1px solid #d4d4d4;
    border-bottom-right-radius: 5px;
    border-top-right-radius: 4px;
    line-height: 1.5em;
    float: left;
    box-shadow: inset 0px 2px 2px #ececec;
}
 </style>
 <script type="text/javascript">
function get_date()
{
     var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!

    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var today = yyyy+'-'+mm+'-'+dd;
    document.getElementById("current_date").value = today;
}

function getViolations() {

   var e = document.getElementById("Voilation_type");
    type = e.options[e.selectedIndex].value;
    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                //alert('done');
                 document.getElementById("fee").value =(xmlhttp.responseText);
               (xmlhttp.responseText);
            }
        };
        xmlhttp.open("GET","ajax.php?fee_id=" + type , true);
        xmlhttp.send();
}


</script>
</head>
<body onload="get_date()">
  <div id="body-wrapper">
    <!-- Wrapper for the radial gradient background -->
    <div id="sidebar">
      <?php include('sidebar.php'); ?>
    </div>
    <!-- End #sidebar -->
    <div id="main-content">
      <!-- Main Content Section with everything -->
      <!-- Page Head -->
      <div class="clear"> </div>
      <div class="content-box">
      <div class="content-box-header"><h3> Voilation Ticket</h3> </div>
      <div class="content-box-content">
        <!-- Start Content Box -->
        <form action="controler.php" method="POST" >
  <fieldset>
    <table class="table">
    <col width="250"/>
    <tr><td class="GridHeader">Car Number:</td>
    <td><input type="text" name="reg_no" value="<?php echo $reg_no;?>" required/></td>
    </tr>
    <tr>
     <td class="GridHeader">Marker Name:</td>
     <td><input type="text" name="marker_name" value="<?php echo $marker_name;?>" required/></td>
    </tr>
    <tr>
    <td class="GridHeader">Model:</td>
    <td><input type="text" name="model" value="<?php echo $model;?>" required/></td>
    </tr>
    <tr>
    <td class="GridHeader">Owner Name:</td>
    <td><input type="text" name="owner_name" value="<?php echo $owner_name;?>" required/></td>
    </tr>
    <tr>
    <td class="GridHeader">Owner Father Name:</td>
    <td><input type="text" name="owner_father_name" value="<?php echo $owner_father_name;?>" required/></td>
    </tr>
    <tr>
    <td class="GridHeader">Chasis Number:</td>
    <td><input type="text" name="chasis_number" value="<?php echo $chasis_number;?>" required/></td>
    <tr>
    <td>Engine Number:</td>
    <td><input type="text" name="engine_number" value="<?php echo $engine_number;?>" required/></td>
    <tr>
    <td>Colour:</td>
    <td><input type="text" name="color" value="<?php echo $color;?>" required/></td>
    <tr>
    <td>Voilation:</td>
    <td><select  id="Voilation_type" name="voilation_type"  onchange="getViolations()">
 <option value="None">None</option>
<option value="1">Wrong Overtake</option>
<option value="2">Wrong Parking</option>
<option value="3">Wrong Uturn</option>
<option value="4">Illegal Horn</option>
</select>
</td>
<tr>
<td>
 Voilation Fee:</td>
<td> <input type="text" id="fee" name="fee" placeholder="Challan Fee" required/>
 </td>
 </tr>
 <tr>
 <td>Date:</td>
 <td><input type="text" id="current_date" name="current_date" required/></td>
 </tr>
 <tr>
 <td>Latitude:</td> 
 <td><input type="text" id="lat" name="lat" value="34.6" required/></td>
 </tr>
 <tr>
 <td>Langitude:</td>
 <td><input type="text" id="lan" name="lan" value="73.9" required/></td>
 <tr>
 <td> City:</td>
 <td><input type="text" id="city" name="city" value="abbottabad" required/></td>
</tr>
    </table>
   <input type="submit" name="form" value="Submit">
  </fieldset>
</form>
</div>
        <!--Your Code goes here this is the rest of thebody wher data will be display -->
     </div>
	 </div>
	  <?php include('footer.php'); ?>
  </div>
       
</div>
</body>
</html>
