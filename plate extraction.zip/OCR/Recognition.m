function [strPlate] = Recognition(Objects,ImgChar)

 %% Load databases numbers and letters for comparison %% 

 Baseletters=im2bw(uint8(imread('Letras.jpg')));
 Baseletters=bwlabel(Baseletters); L=regionprops(Baseletters,'all');
letters={'A','N','B','O','P','C','Q','D','R','E','S','F','T','G',' U','H','V','I','J','W','K','X','L','Y','M','Z'}; 

 letters1={'A','N','B','O','P','C','O','D','R','E','S','F','T','O', 'U','H','V','I','J','W','K','X','L','Y','M','Z'}; 
 for i=1:26
     L(i).Image=imresize(L(i).Image,[100 100]);
 end 
 
 N=struct('Image',{});
 numbers={'0','1','2','3','4','5','6','7','8','9'}; 
   
 N(1).Image=imresize(im2bw(uint8(imread('0.png'))),[100 100]); 
 N(2).Image=imresize(im2bw(uint8(imread('1.png'))),[100 100]); 
 N(3).Image=imresize(im2bw(uint8(imread('2.png'))),[100 100]); 
 N(4).Image=imresize(im2bw(uint8(imread('3.png'))),[100 100]); 
 N(5).Image=imresize(im2bw(uint8(imread('4.png'))),[100 100]); 
 N(6).Image=imresize(im2bw(uint8(imread('5.png'))),[100 100]); 
 N(7).Image=imresize(im2bw(uint8(imread('6.png'))),[100 100]); 
 N(8).Image=imresize(im2bw(uint8(imread('7.png'))),[100 100]); 
 N(9).Image=imresize(im2bw(uint8(imread('8.png'))),[100 100]); 
 N(10).Image=imresize(im2bw(uint8(imread('9.png'))),[100 100]); 
 
 %% Treat the image depending on the number of objects found %% 
 
 I=ImgChar; 

 %% Maximum of objects is 8, if more, you must remove the leftover% 
  
 if (Objects>8) 
    
     for i=1:Objects 
        char=I(:,:,i);
         char=not(uint8(char));
         list_corr=[];
         for j=1:26 
             corr=corr2(L(j).Image,char);
             list_corr=[list_corr corr];
         end 
         for j=1:10 
             corr=corr2(N(j).Image,char); 
             list_corr=[list_corr corr];
         end 
         f=max(list_corr); 
        if f<0.3 
             ImgChar(:,:,i)=0;
         end
     end 
   
     for p=1:Objects 
         if min(min(not(ImgChar(:,:,p))))==1;
             for l=p:(Objects-1)  
                 ImgChar(:,:,l)=ImgChar(:,:,l+1);
             end 
             ImgChar(:,:,l)=ImgChar(:,:,l+1);
             Objects=Objects-1; 
         end 
     end 
 end 
 
 %% Distinguish between 6, 7 or 8 objects for correlation %% 
 
 if Objects==6 
 
    strPlate=[]; 
for i=1:Objects
       char=ImgChar(:,:,i);
         char=not(uint8(char)); 
  
        if (i==1) || (i==6) 
             list_corr=[]; 
             for j=1:26 
                 corr=corr2(L(j).Image,char);
                 list_corr=[list_corr corr];
            end 
            f=max(list_corr); 
             maxcorr=find(list_corr==f); 
             strPlate=[strPlate letters(maxcorr)];
         end 
 
        if (i==2) || (i==3) || (i==4) || (i==5) 
             list_corr=[]; 
             for j=1:10 
                 corr=corr2(N(j).Image,char); 
                 list_corr=[list_corr corr];
             end 
             f=max(list_corr); 
            maxcorr=find(list_corr==f);
             strPlate=[strPlate numbers(maxcorr)];
         end 
     end 
 end 
   
if Objects==8  
  
     strPlate=[];
  for i=1:Objects 
     char=ImgChar(:,:,i); 
      char=not(uint8(char)); 
  
     if (i==1) || (i==7) || (i==8)
         list_corr=[];
         for j=1:26 
             corr=corr2(L(j).Image,char); 
              list_corr=[list_corr corr]; 
         end 
           f=max(list_corr); 
        maxcorr=find(list_corr==f); 
           strPlate=[strPlate letters(maxcorr)]; 
        end 
         
      if (i==2)
           list_corr=[]; 
          for j=1:26 
             corr=corr2(L(j).Image,char); 
            list_corr=[list_corr corr]; 
          end 
       f=max(list_corr);
         maxcorr=find(list_corr==f); 
          strPlate=[strPlate letters1(maxcorr)];
       end 
      
    if (i==3) || (i==4) || (i==5) || (i==6)
            list_corr=[]; 
           for j=1:10 
               corr=corr2(N(j).Image,char);
                list_corr=[list_corr corr]; 
            end 
            f=max(list_corr); 
             maxcorr=find(list_corr==f);
             strPlate=[strPlate numbers(maxcorr)]; 
         end 
     end 
 end 
 
 if Objects==7 

    strPlate=[];
 for i=1:Objects
      char=ImgChar(:,:,i);
      char=not(uint8(char)); 
      if (i==1) || (i==7)
        list_corr=[]; 
        for j=1:26
            corr=corr2(L(j).Image,char); 
            list_corr=[list_corr corr]; 
         end 
        f=max(list_corr); 
        maxcorr=find(list_corr==f); 
       strPlate=[strPlate letters(1,maxcorr)]; 
    end 
 
     if (i==3) || (i==4) || (i==5)  
         list_corr=[];
     for j=1:10 
           corr=corr2(N(j).Image,char);
              list_corr=[list_corr corr];
         end 
        f=max(list_corr); 
         maxcorr=find(list_corr==f);
          strPlate=[strPlate numbers(1,maxcorr)]; 
    end 
  
       if (i==2)
         list_corr=[]; 
         for j=1:26 
              corr=corr2(L(j).Image,char);
               list_corr=[list_corr corr]; 
             end 
for j=1:10 
           corr=corr2(N(j).Image,char);
            list_corr=[list_corr corr]; 
        end 
          f=max(list_corr); 
       maxcorr=find(list_corr==f); 
        if maxcorr>26 
             strPlate=[strPlate numbers(1,maxcorr-26)];
          else
              strPlate=[strPlate letters1(1,maxcorr)];
             end 
         end 
        
         if (i==6) 
             list_corr=[]; 
             for j=1:26 
                 corr=corr2(L(j).Image,char); 
                 list_corr=[list_corr corr];
             end 
             for j=1:10 
                 corr=corr2(N(j).Image,char);
                 list_corr=[list_corr corr];
             end 
             f=max(list_corr);
             maxcorr=find(list_corr==f);
             if maxcorr>26
                 strPlate=[strPlate numbers(1,maxcorr-26)]; 
             else
                 strPlate=[strPlate letters(1,maxcorr)]; 
             end 
   
      end 
   
  end 
 end  
%% If there aren't between 6 and 8 objects, the number plate is wrong %% 

     if (Objects<6) || (Objects>8) 
         for i=1:8
          strPlate{i}=0; 
    
  end
     end
 end
 