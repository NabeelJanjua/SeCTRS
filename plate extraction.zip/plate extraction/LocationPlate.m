function [ImgPlate] = LocationPlate(I)
  
 %% Cutting and resizing the original image %% 
 
 [rows columns]=size(I); 
% columns=columns/3; 
%  xmin=round(0.20*rows); 
% ymin=round(0.20*columns);
%  width=round((0.85*columns)-(0.10*columns));
%  height=round((0.85*rows)-(0.15*rows));
%  Io=imcrop(I,[xmin ymin width height]);
Io=I;
Io=imresize(Io,[480 640]);
 Io=rgb2gray(Io); 
 Io=imadjust(Io);
  
%% Image processing to focus the area of number plate %% 
 %% Smooth edges and contours to delete characters.
 %% Subtracting the original image to obtain the information  
%% previously deleted and thus stay with the characters.
 %% Select the elements with a higher level of 85.
 %% Pass a mask to the image to remove excess information common to 
 %% all images. 
  
 se=strel('rectangle',[6 30])      
 Ic=imclose(Io,se); 
Ic=imadjust(Ic);
 tophat=Ic-Io;  
 Ibw1=(tophat>85);
  Ibw=Ibw1 & im2bw(imread('r.jpg'));
 
 % Ibw=Ibw1 & im2bw(imread('C:\Users\Umer Hamdan\Desktop\LPR\*marco.jpg'));  
 
 %% Remove the related elements with fewer than 70 pixels %% 
 %% Remove objects that are not plate %% 
 
 plate= bwlabel(Ibw,4);   %Label connected components in 2-D binary image     
obj= max(max(plate));         
 dim1 = regionprops(plate, 'area')'; 
 dim=[dim1.Area];    %find the area size in dim1 and then less than 70 ,=0;
 dim(find(dim<70))=0;  
               
 for i=1:obj     %find the plate label and save to index,dim(i)
    index=find(plate==i); 
     if dim(i)==0 
         plate(index)=0;
    else  
         plate(index)=1; 
     end 
   

end 
 
 CC=bwconncomp(plate); 
 P=regionprops(CC,'all'); 
 [rp cp]=size(plate);  
 for i=1:CC.NumObjects
  
     if P(i).MajorAxisLength>(2*cp/3) 
         plate(P(i).PixelIdxList(:,1))=0;%????????
     end 
    
 end 
 
 %% Remove objects that are not candidates for plate %% 
  
 se3=strel('rectangle',[30 70]); 
r2=imclose(plate,se3);
 
 se2=strel('rectangle',[5 30]);
 r=imdilate(r2,se2);
  
 CC=bwconncomp(r); 
 P=regionprops(CC,'all');
   
 for i=1:CC.NumObjects 
 
     if P(i).MajorAxisLength>(2*cp/3) 
         r(P(i).PixelIdxList(:,1))=0; 
     end 
   
 end 
  
 %% select the largest connected component after preprocessing, the 
%%plate 
 
 plate1= bwlabel(r,4); 
 dim2= regionprops(plate1, 'area')';
 dim1=[dim2.Area]; 
 f=max(dim1); 
 indMax=find(dim1==f); 
 plate1(find(plate1~=indMax))=0; 
 
 %% cutting of original image %% 
  
 [cuty, cutx] = find( plate1 > 0); 
 up = min(cuty);
    down = max(cuty); 
 left = min(cutx); 
 right = max(cutx); 
  
 img_cut_v = Io(up:down,:,:);
 img_cut_h = img_cut_v(:,left:right,:); 
   
 ImgPlate = img_cut_h; 
 
 %% different mask for location plate %% 
 
 [r c]=size(ImgPlate); 
 if r<25 || r>65 

    [rows columns]=size(I);
     columns=columns/3;
     xmin=round(0.20*rows); 
     ymin=round(0.20*columns);
     width=round((0.85*columns)-(0.10*columns)); 
     height=round((0.85*rows)-(0.15*rows));
     Io=imcrop(I,[xmin ymin width height]);
     Io=imresize(Io,[480 640]); 
     Io=rgb2gray(Io); 
     Io=imadjust(Io); 
     
     se=strel('rectangle',[6 30]);            
     Ic=imclose(Io,se); 
     Ic=imadjust(Ic);
     tophat=Ic-Io;             
    Ibw1=(tophat>85);
     mask=zeros(480,640);
  
     for i=40:370 131     
 for j=40:575 132       
   mask(i,j)=1; 
         end 
     end 
     
    Ibw=Ibw1 & im2bw(mask); 
     plate= bwlabel(Ibw,4);         
     obj= max(max(plate));    
     dim1 = regionprops(plate, 'area')'; 
    dim=[dim1.Area];    
    dim(find(dim<70))=0; 
    
     for i=1:obj 
         index=find(plate==i); 
         if dim(i)==0 146             
plate(index)=0; 147        
else 
          plate(index)=1;
         end 
     end 
    
     CC=bwconncomp(plate);
     P=regionprops(CC,'all');
     [rp cp]=size(plate); 
    
     for i=1:CC.NumObjects 
       if P(i).MajorAxisLength>(cp/3) 
         plate(P(i).PixelIdxList(:,1))=0;
       end 
     end 
    
     se3=strel('rectangle',[30 70]);
     r2=imclose(plate,se3); 
    se2=strel('rectangle',[5 30]);
     r=imdilate(r2,se2); 
   
     plate1= bwlabel(r,4); 
     dim2= regionprops(plate1, 'area')'; 
     dim1=[dim2.Area]; 
     f=max(dim1); 
     indMax=find(dim1==f); 
     plate1(find(plate1~=indMax))=0; 
      
     [cuty, cutx] = find( plate1 > 0); 
     up = min(cuty); 
     down = max(cuty); 
     left = min(cutx); 
     right = max(cutx); 
     img_cut_v = Io(up:down,:,:);
     img_cut_h = img_cut_v(:,left:right,:);
     ImgPlate = img_cut_h; 
     
 end 
   
 %% Representation %% 
  
 % figure(1); 
 % imshow(I); 
 % subplot(2,2,1);imshow(I); 
 % subplot(2,2,2);imshow(Ic); 
 % subplot(2,2,3);imshow(plate);
 % subplot(2,2,4);imshow(plate1);
 
  %figure(2);
  
 % imshow(img_cut_h);title('output location plate');
  ImgPlate=img_cut_h;
   end
