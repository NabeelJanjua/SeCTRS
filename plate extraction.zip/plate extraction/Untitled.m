obj=VideoReader('1234.mpg ');
nFrames=obj.NumberOfFrames;
for k=25:50
    img=read(obj,k);    
    figure(1),imshow(img);
    ImgPlate=LocationPlate(img);
  imshow(ImgPlate);title('output location plate');
    pause
end