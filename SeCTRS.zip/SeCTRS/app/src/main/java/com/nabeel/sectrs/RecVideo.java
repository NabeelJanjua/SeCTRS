package com.nabeel.sectrs;

import android.app.Activity;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.media.audiofx.BassBoost;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.coremedia.iso.boxes.Container;
import com.googlecode.mp4parser.authoring.Movie;
import com.googlecode.mp4parser.authoring.Track;
import com.googlecode.mp4parser.authoring.builder.DefaultMp4Builder;
import com.googlecode.mp4parser.authoring.container.mp4.MovieCreator;
import com.googlecode.mp4parser.authoring.tracks.AppendTrack;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class RecVideo extends Activity {

    Boolean present=false;
    ConnectionDetector cd;
    private Camera myCamera;
    private MyCameraSurfaceView myCameraSurfaceView;
    private MediaRecorder mediaRecorder;
    public static int orientation;
    Button myButton, btn_comp;
    SurfaceHolder surfaceHolder;
    boolean recording;
    String btn2;
    TextView lblLocation;
    GPSTracker gps;

    boolean path;
    //File video_file;
    static String file_path1 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Sectrs/Aa.mp4";
    static String file_path2 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Sectrs/Ab.mp4";
    static String file_path3 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/output_append.mp4";
    static String file_path4 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/EncryptVideo.mp4";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        recording = false;
        btn2 = "false";

        setContentView(R.layout.activity_main);

        cd= new ConnectionDetector(getApplication());
        present = cd.isConToInternet();
        if(present){
            Toast.makeText(getApplicationContext(),"Connected",Toast.LENGTH_LONG).show();

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Not Connected",Toast.LENGTH_LONG).show();
        startActivity(new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS));
        }



        myCamera = getCameraInstance();

        if (new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Sectrs/Aa.mp4").delete()) {
           // Toast.makeText(getApplicationContext(),"deleted",Toast.LENGTH_LONG).show();

        } else {

            // Not deleted
        }if (new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Sectrs/Ab.mp4").delete()) {
           // Toast.makeText(getApplicationContext(),"deleted",Toast.LENGTH_LONG).show();

        } else {

            // Not deleted
        }
        if (new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Sectrs/output_append.mp4").delete()) {

        } else {
            // Not deleted
        }

        findViewById(R.id.btn_merge).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    mergeClips();

                }
                catch (Exception e)
                {

                }
            }
        });


//Get Camera for preview


        if (myCamera == null) {
            Toast.makeText(RecVideo.this, "Fail to get Camera", Toast.LENGTH_LONG).show();
        }

        myCameraSurfaceView = new MyCameraSurfaceView(this, myCamera, this);
        FrameLayout myCameraPreview = (FrameLayout) findViewById(R.id.videoview);
        myCameraPreview.addView(myCameraSurfaceView);

        myButton = (Button) findViewById(R.id.mybutton);
        btn_comp = (Button) findViewById(R.id.btn_comp);
        myButton.setOnClickListener(myButtonOnClickListener);
        btn_comp.setOnClickListener(btn_compOnClickListener);

//    startRecording();
    }

    Button.OnClickListener btn_compOnClickListener = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {
                if (recording && btn2 == "true") {
                    Toast.makeText(getApplicationContext(), "Violation Video Now Recording", Toast.LENGTH_LONG).show();
                    mediaRecorder.stop();  // stop the recording
                    releaseMediaRecorder();
                    btn_comp.setText("Violation");
                    recording = false;
                    path = true;
                    releaseCamera();
                    if (!prepareMediaRecorder()) {
                        Toast.makeText(RecVideo.this,
                                "Failed to prepareMediaRecorder()!\n - Ended -",
                                Toast.LENGTH_LONG).show();
                        finish();
                    }
                    mediaRecorder.start();
                    recording = false;
                    btn2 = "false";
                    btn_comp.setText("STOP2");
                }
                else{
                    recording = true;
                    btn_comp.setText("Violation");
                    btn2 = "true";
                    Toast.makeText(getApplicationContext(), "Both Video Recorded", Toast.LENGTH_LONG).show();
                    mediaRecorder.stop();  // stop the recording
                    releaseMediaRecorder();

                    Context c= getApplicationContext();

                    // create class object
                    gps = new GPSTracker(RecVideo.this);
                    // check if GPS enabled
                    if(gps.canGetLocation()){
                        double latitude = gps.getLatitude();
                        double longitude = gps.getLongitude();
                        // \n is for new line
                        Toast.makeText(getApplicationContext(), "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
                    }else{
                        // can't get location
                        // GPS or Network is not enabled
                        // Ask user to enable GPS/network in settings
                        gps.showSettingsAlert();
                    }

//                    try {
//                        GetGps g = new GetGps();
//                        g.displayLocation();
//                    }
//                    catch(Exception e)
//                    {
//                        Toast.makeText(c,"Error"+e,Toast.LENGTH_LONG).show();
//                    }

                    DbHandler db=new DbHandler(RecVideo.this, null, null, 1);
                    long result=db.addVideo("First video","23","344","12:34","abtbd");

                    if(result>0){
                        Toast.makeText(getApplicationContext(),"Successfully added", Toast.LENGTH_LONG).show();
                    }
                    else
                        Toast.makeText(getApplicationContext(), "Unsuccessful", Toast.LENGTH_LONG).show();



                    Encrypt e=new Encrypt();

                    e.encryptVideos(file_path3, file_path4, c);//Encryption call
                    e.decrypt(file_path4, c);//Encryption call
                    Intent intent=new Intent(RecVideo.this,UploadList.class);
                    startActivity(intent);



                    //  lblLocation.setText( g.displayLocation(c));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };

    Button.OnClickListener myButtonOnClickListener
            = new Button.OnClickListener() {


        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub


            try {
                if (recording) {
                    // stop recording and release camera
                    mediaRecorder.stop();  // stop the recording
                    releaseMediaRecorder(); // release the MediaRecorder object
                    myButton.setText("START");
                    recording = false;
                } else {
                    //Release Camera before MediaRecorder start
                    releaseCamera();
                    //myButton.setText("STOP");

                    if (!prepareMediaRecorder()) {
                        Toast.makeText(RecVideo.this,
                                "Failed to prepareMediaRecorder()!\n - Ended -",
                                Toast.LENGTH_LONG).show();
                        finish();
                    }
                    mediaRecorder.start();
                    recording = true;
                    btn2 = "true";
                    myButton.setText("STOP");


                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }
    };

    private Camera getCameraInstance() {
        // TODO Auto-generated method stub
        Camera c = null;
        try {
            c = Camera.open(0); // get a Camera instance
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)
        }
        return c; // returns null if camera is unavailable
    }


    private boolean prepareMediaRecorder() throws IOException {
        myCamera = getCameraInstance();

        // Potrait Orientation.
        setCameraDisplayOrientation(this, 0, myCamera);

        mediaRecorder = new MediaRecorder();
        myCamera.unlock();

        mediaRecorder.setCamera(myCamera);

        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);


        CamcorderProfile cpHigh = CamcorderProfile
                .get(CamcorderProfile.QUALITY_480P);
        mediaRecorder.setProfile(cpHigh);
        mediaRecorder.setMaxDuration(50000); // 50 seconds
        mediaRecorder.setMaxFileSize(5000000); // Approximately 5 megabytes
        String file_path="";
        if (path) {
            //video_file = new File(file_path1);
            file_path=file_path1;
        } else {
            //video_file = new File(file_path2);
            file_path=file_path2;
        }


        mediaRecorder.setOutputFile(String.valueOf(file_path));
        // mediaRecorder.setMaxDuration(60000); // Set max duration 60 sec.

        //video_file.length();



        // mediaRecorder.setMaxFileSize(10000000); // Set max file size 10Mb

        mediaRecorder.setPreviewDisplay(myCameraSurfaceView.getHolder().getSurface());
        mediaRecorder.setOrientationHint(RecVideo.orientation);
        try {
            mediaRecorder.prepare();
        } catch (IllegalStateException e) {
            releaseMediaRecorder();
            return false;
        } catch (IOException e) {
            releaseMediaRecorder();
            return false;
        }
        return true;

    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseMediaRecorder();       // pause event
    }

    private void releaseMediaRecorder() {
        if (mediaRecorder != null) {
            mediaRecorder.reset();   // clear recorder configuration
            mediaRecorder.release(); // release the recorder object
            mediaRecorder = new MediaRecorder();
            myCamera.lock();           // lock camera for later use
        }
    }

    private void releaseCamera() {
        if (myCamera != null) {
            myCamera.release();        // release the camera
            myCamera = null;
        }
    }

    ///////////////////////////////////////////////////
    public void mergeClips() throws IOException {
        try {
//
            boolean bool=append() ;
            i=0;
            Toast.makeText(getApplicationContext(), "merged " + bool + " " + i, Toast.LENGTH_LONG).show();

            String video = file_path1;
            try {
                Movie countVideo = MovieCreator.build(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Aa.mp4");
                Toast.makeText(getApplicationContext(), "Nabeel", Toast.LENGTH_LONG).show();
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(), "Err" + e.toString(), Toast.LENGTH_LONG).show();
                Log.v("Error", e.toString());
            }

        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "hello " + e.getMessage(), Toast.LENGTH_LONG).show();
        }


    }


    int i=0;
    ////////////////////////////////////////////////////
    private boolean append() {
        try {
            // ??????????
            i=1;
            Movie[] inMovies = new Movie[]{
                    MovieCreator.build(file_path1),
                    MovieCreator.build(file_path2)};

            // 1?????????
            i=2;//2
            List<Track> videoTracks = new LinkedList<Track>();
            i=3;
            List<Track> audioTracks = new LinkedList<Track>();
            i=4;
            for (Movie m : inMovies) {
                i=5;
                for (Track t : m.getTracks()) {
                    i=6;
                    if (t.getHandler().equals("soun")) {
                        i=7;
                        audioTracks.add(t);
                    }
                    i=8;
                    if (t.getHandler().equals("vide")) {
                        i=9;
                        videoTracks.add(t);
                    }
                    i=10;
                }
                i=11;
            }
            i=12;
            Movie result = new Movie();
            i=13;
            if (audioTracks.size() > 0) {
                i=14;
                result.addTrack(new AppendTrack(audioTracks.toArray(new Track[audioTracks.size()])));
            }
            i=15;
            if (videoTracks.size() > 0) {
                result.addTrack(new AppendTrack(videoTracks.toArray(new Track[videoTracks.size()])));
            }

            // ??
            Container out = new DefaultMp4Builder().build(result);
            String outputFilePath = Environment.getExternalStorageDirectory() + "/output_append.mp4";
            FileOutputStream fos = new FileOutputStream(new File(outputFilePath));
            out.writeContainer(fos.getChannel());
            fos.close();
            Intent i = new Intent(RecVideo.this,UploadActivity.class);
            i.putExtra("FileName",file_path3);
            startActivity(i);
        } catch (Exception e) {
            //Toast.makeText(getApplicationContext(), " Nabeel ", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }




    public class MyCameraSurfaceView extends SurfaceView implements SurfaceHolder.Callback {

        private SurfaceHolder mHolder;
        private Camera mCamera;
        private Activity mActivity;

        public MyCameraSurfaceView(Context context, Camera camera, Activity activity) {
            super(context);
            mCamera = camera;
            mActivity = activity;
            // Install a SurfaceHolder.Callback so we get notified when the
            // underlying surface is created and destroyed.
            mHolder = getHolder();
            mHolder.addCallback(this);
            // deprecated setting, but required on Android versions prior to 3.0
            mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        }

        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            try {
                setCameraDisplayOrientation(mActivity, 0, mCamera);
                previewCamera();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void previewCamera() {
            try {
                mCamera.setPreviewDisplay(mHolder);
                mCamera.startPreview();
            } catch (Exception e) {
                //Log.d(APP_CLASS, "Cannot start preview", e);
            }
        }


        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            // TODO Auto-generated method stub
            // The Surface has been created, now tell the camera where to draw the preview.
            try {
                mCamera.setPreviewDisplay(holder);
                mCamera.startPreview();
            } catch (IOException e) {
            }
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            // TODO Auto-generated method stub

        }


    }

    public static void setCameraDisplayOrientation(Activity activity,
                                                   int cameraId, android.hardware.Camera camera) {

        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();

        android.hardware.Camera.getCameraInfo(cameraId, info);

        int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;

        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        RecVideo.orientation = result;
        camera.setDisplayOrientation(result);
    }
}