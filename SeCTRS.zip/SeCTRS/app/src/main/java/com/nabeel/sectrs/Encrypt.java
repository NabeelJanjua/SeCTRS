package com.nabeel.sectrs;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by Nabeel on 3/7/2016.
 */
public class Encrypt{

    public  void encryptVideos(String fil,String outfile, Context c)
    {
        File f1= new File(fil);
        File f2= new File(outfile);
        //AlgorithmParameterSpec spec = getIV();

        try{
            Toast.makeText(c, "Inside Encrypt2 Method", Toast.LENGTH_LONG).show();
            FileInputStream fis = new FileInputStream(f1);
            //File outfile = new File(fil2);
            int read;
            if(!f2.exists())
                f2.createNewFile();
            FileOutputStream fos = new FileOutputStream(f2);
            //FileInputStream encfis = new FileInputStream(f2);
            Cipher encipher = Cipher.getInstance("AES");
            //KeyGenerator kgen = KeyGenerator.getInstance("AES");
            SecretKeySpec skey = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");
            //byte key[] = {0x00,0x32,0x22,0x11,0x00,0x00,0x00,0x00,0x00,0x23,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
            //SecretKey skey = kgen.generateKey();
            Toast.makeText(c, "key"+skey.toString(), Toast.LENGTH_LONG).show();
            //Lgo
            encipher.init(Cipher.ENCRYPT_MODE, skey);
            CipherOutputStream cis = new CipherOutputStream(fos, encipher);
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1)
            {
                cis.write(buffer, 0, bytesRead);
            }
            cis.flush();
            cis.close();
            fis.close();

        }catch (Exception e) {
            // TODO: handle exception
        }
    }

    public void decrypt(String outfile, Context context) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {


        Toast.makeText(context, "Inside Decrypt Method", Toast.LENGTH_LONG).show();
        File f2= new File(outfile);
        FileInputStream fis = new FileInputStream(f2);

        FileOutputStream fos = new FileOutputStream(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DecVideo.mp4");
        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, sks);
        CipherInputStream cis = new CipherInputStream(fis, cipher);
        int b;
        byte[] d = new byte[8192];
        while((b = cis.read(d)) != -1) {
            fos.write(d, 0, b);
        }
        fos.flush();
        fos.close();
        cis.close();
    }

//    public AlgorithmParameterSpec getIV() {
//        byte[] iv = { 1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6 };
//        IvParameterSpec ivParameterSpec;
//        ivParameterSpec = new IvParameterSpec(iv);
//
//        return ivParameterSpec;
//    }
}
