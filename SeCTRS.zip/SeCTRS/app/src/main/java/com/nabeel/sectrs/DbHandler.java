package com.nabeel.sectrs;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nabeel on 3/15/2016.
 */
public class DbHandler extends SQLiteOpenHelper {

    static String DATABASE_NAME="DbCADMARS";
    static int VERSION =3;

    /////////1st Table///////////
    String TABLE_INFO="TBL_Video";
    String _video ="Video";
    String _lat ="Lat";
    String _longi ="Longi";
    String _loc ="Loc";
    String _time ="Time";




    public DbHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {

        super(context, DATABASE_NAME, factory, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        ///////////TABLE 1///////////////
        String query="CREATE TABLE "+TABLE_INFO+" ( "+ _video +" TEXT, "
                + _lat +" TEXT, "
                + _longi +" TEXT,"
                + _loc +" TEXT,"
                + _time +" TEXT) ";
        db.execSQL(query);
        Log.e("ALRIGHT", "Done Table Created");

        ////////////TABLE 2////////////////

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INFO);
        onCreate(db);


    }

    long  addVideo(String path,String lat,String longi,String time, String loc){
        ContentValues values = new ContentValues();
        values.put(_video,path);
        values.put(_lat,lat);
        values.put(_longi,longi);
        values.put(_loc,loc);
        values.put(_time, time);
        SQLiteDatabase db=this.getWritableDatabase();
        long l=db.insert(TABLE_INFO,null,values);
        Log.e("DB", "DONE");
        db.close();
        return l;
    }



    ////////////GETTING DETAILS FOR LOGIN/////////

    List<DatabaseDetails> getLoginDetails()
    {

        List<DatabaseDetails> Li = new ArrayList<DatabaseDetails>();
        // Select All Query
        String selectQuery = "SELECT * FROM "+ TABLE_INFO;

        SQLiteDatabase db = this.getWritableDatabase();  // When read and write something in database
        Cursor cursor = db.rawQuery(selectQuery, null);  // Through cursor Retrieve Every value

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                DatabaseDetails LD = new DatabaseDetails();

                LD.setVideoName(cursor.getString(0));
                LD.setLat(cursor.getString(1));
                LD.setLongt(cursor.getString(2));
                LD.set_loc(cursor.getString(3));
                LD.setTime(cursor.getString(4));
                // Adding contact to list
                Li.add(LD);
            } while (cursor.moveToNext());
        }

        // return users list
        return Li;
    }

}

