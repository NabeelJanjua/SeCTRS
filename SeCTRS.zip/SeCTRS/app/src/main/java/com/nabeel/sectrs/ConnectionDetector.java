package com.nabeel.sectrs;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * Created by Nabeel on 3/14/2016.
 */
public class ConnectionDetector {
    private Context con;

    public ConnectionDetector(Context context){

        this.con= context;

    }

    public boolean isConToInternet(){

        ConnectivityManager connect= (ConnectivityManager)con.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(connect!=null)
        {
            NetworkInfo[] info = connect.getAllNetworkInfo();

            if(info!=null)
                for(int i=0; i<info.length; i++)
                    if(info[i].getState()== NetworkInfo.State.CONNECTED)
                    {
                        return true;

                    }


        }

        return false;
    }
                }
