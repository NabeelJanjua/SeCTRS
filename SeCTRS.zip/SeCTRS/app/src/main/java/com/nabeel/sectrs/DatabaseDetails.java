package com.nabeel.sectrs;

/**
 * Created by Nabeel on 3/15/2016.
 */
public class DatabaseDetails {

    private String VideoName;
    private String lat;
    private String longt;
    private String time;
    private String _loc;


    public String get_loc() {
        return _loc;
    }

    public void set_loc(String _loc) {
        this._loc = _loc;
    }



    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLongt() {
        return longt;
    }

    public void setLongt(String longt) {
        this.longt = longt;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getVideoName() {
        return VideoName;
    }

    public void setVideoName(String videoName) {
        this.VideoName = videoName;
    }


}
